/*
	Drop databases
*/

DROP DATABASE [AdventureWorks2014];
GO

DROP DATABASE [AuntMarjorie]
GO

DROP DATABASE [Harry]
GO

DROP DATABASE [Charlie]
GO

DROP DATABASE [Violet];
GO
